a = [0, -0.24355, -0.2132, 0, 0, 0] # Link Length
		
		# Using D-H table to generate transformation matr